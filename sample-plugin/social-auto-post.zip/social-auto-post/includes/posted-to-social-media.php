<style>
.order-tbl-wrap table {background-color: #F9F9F9;border:1px solid #DFDFDF; width:98%; margin-bottom:25px;}
.order-tbl-wrap table td {font-size: 12px;  padding: 5px 7px 5px; vertical-align: top; color:#555555; border-bottom:1px solid #DFDFDF;}
.order-tbl-wrap table tr:last-child td { border-bottom:0px;}  
</style>

<h3>Posted On Social Media</h3>
<div class="order-tbl-wrap">
</div>